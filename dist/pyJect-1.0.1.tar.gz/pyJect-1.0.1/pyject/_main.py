'''
	__name__ = {}
	__author__ = {}
	__date__ = {}
'''


def test():
	pass

def main():
	test()

if __name__ == "__main__":
	main()
