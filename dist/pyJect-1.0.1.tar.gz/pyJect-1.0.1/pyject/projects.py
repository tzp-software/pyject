'''
	pyject.projects.py
'''

def create_project(projectName):
	print 'Creating a new project named {}'.format(projectName)


