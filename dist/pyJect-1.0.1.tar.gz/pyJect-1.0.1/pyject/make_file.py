'''
	pyject.make_file.py
'''

def add_module(projectName,moduleName):
	print 'adding module named {} to project {}'.format(moduleName,projectName)

