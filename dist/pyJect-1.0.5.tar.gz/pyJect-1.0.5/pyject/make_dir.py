'''
	pyject.make_dir.py
'''

def add_package(projectName,packageName):
	print 'Adding package {} to project {}'.format(packageName,projectName)


